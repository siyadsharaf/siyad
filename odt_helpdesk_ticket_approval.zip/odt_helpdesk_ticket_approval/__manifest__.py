# -*- coding: utf-8 -*-
{
    'name': "odt_helpdesk_ticket_approval",
    'summary': """
        Adding approvals to internal Validation in Helpdesk Ticket""",
    'author': "Odootec",
    'website': "http://www.odootec.com",
    'category': 'Helpdesk',
    'version': '0.3',
    'depends': ['helpdesk','website_helpdesk_form'],
    'data': [
        'views/views.xml',
    ],
}

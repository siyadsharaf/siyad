# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError

class HelpdeskStage(models.Model):
    _inherit = 'helpdesk.stage'

    internal_validation_stage = fields.Boolean('Internal Validation Stage')
    rejected_stage = fields.Boolean('Rejected Stage')

class odt_helpdesk__ticket_edit(models.Model):
    _inherit = 'helpdesk.ticket'

    approval_bool_1 = fields.Boolean('1st Approval', track_visibility='onchange')
    approval_bool_2 = fields.Boolean('2nd Approval', track_visibility='onchange')
    approval_user_id_1 = fields.Many2one('res.users',string='Approver',readonly=True,store=True)
    approval_user_id_2 = fields.Many2one('res.users',string='Approver',readonly=True,store=True)
    development_desk = fields.Boolean('Development Helpdesk',compute='compute_development_helpdesk')
    @api.onchange('approval_bool_1')
    def on_change_approval_id_1(self):
        if self.approval_bool_1:
            if self.env.user.help_desk_ticket_approver:
                self.approval_user_id_1 = self.env.user.id
            else:
                raise ValidationError ("You are not authorized to make approvals")
        else:
            self.approval_user_id_1 = False
        if self.approval_user_id_2:
            if self.env.user.id == self.approval_user_id_2.id:
                self.approval_bool_1 =False
                raise ValidationError ("You can't make Multiple approvals")

    @api.onchange('approval_bool_2')
    def on_change_approval_id_2(self):
        if self.approval_bool_2:
            if self.env.user.help_desk_ticket_approver:
                self.approval_user_id_2 = self.env.user.id
            else:
                raise ValidationError ("You are not authorized to make approvals")
        else:
            self.approval_user_id_2 = False
        if self.approval_user_id_1:
            if self.env.user.id == self.approval_user_id_1.id:
                self.approval_bool_2 =False
                raise ValidationError("You can't make Multiple approvals")

    @api.onchange('stage_id')
    def on_change_stage_id_approval(self):
        if self.stage_id:
            if not self.stage_id.rejected_stage:
                if self.stage_id.sequence:
                    if self.stage_id.internal_validation_stage and self.development_desk:
                        if not (self.approval_user_id_2 and self.approval_user_id_1):
                            raise ValidationError("You can't change the stage without Approvals")

    @api.depends('team_id')
    def compute_development_helpdesk(self):
        for record in self:
            if record.team_id:
                record.development_desk=record.team_id.development_desk

class HelpDeskTeam(models.Model):
    _inherit = 'helpdesk.team'

    development_desk = fields.Boolean('Development Helpdesk')

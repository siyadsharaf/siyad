# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError

class ResUsers(models.Model):
    _inherit = 'res.users'

    help_desk_ticket_approver = fields.Boolean('Helpdesk ticket Approver')
